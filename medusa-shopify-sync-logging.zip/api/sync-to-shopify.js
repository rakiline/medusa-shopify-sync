
const axios = require("axios");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { order } = req.body;
  if (!order) {
    console.error("No order provided in body");
    return res.status(400).json({ error: "No order provided" });
  }

  try {
    const shopifyPayload = {
      order: {
        email: order.email,
        financial_status: "paid",
        line_items: order.items.map((item) => ({
          title: item.title,
          quantity: item.quantity,
          price: item.unit_price / 100,
        })),
        shipping_address: {
          name: `${order.shipping_address.first_name} ${order.shipping_address.last_name}`,
          address1: order.shipping_address.address_1,
          city: order.shipping_address.city,
          province: order.shipping_address.province,
          zip: order.shipping_address.postal_code,
          country: order.shipping_address.country_code,
        },
        customer: {
          email: order.email,
          first_name: order.shipping_address.first_name,
          last_name: order.shipping_address.last_name,
        },
        note: `Synced from Medusa Order ID: ${order.id}`,
        tags: ["From Medusa"],
      },
    };

    console.log("📦 Sending payload to Shopify:", JSON.stringify(shopifyPayload, null, 2));

    const response = await axios.post(
      "https://stickerswan.myshopify.com/admin/api/2023-10/orders.json",
      shopifyPayload,
      {
        headers: {
          "X-Shopify-Access-Token": process.env.SHOPIFY_ADMIN_TOKEN,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("✅ Shopify order created:", response.data);
    res.status(200).json({ success: true, shopifyOrder: response.data.order });
  } catch (err) {
    console.error("❌ Shopify Order Sync Failed:", err.response?.data || err.message);
    res.status(500).json({ error: err.message });
  }
};
